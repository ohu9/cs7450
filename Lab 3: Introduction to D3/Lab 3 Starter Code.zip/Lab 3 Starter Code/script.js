const data = [
    { x: 30,  y: 20,  value: 10, category: "A" },
    { x: 85,  y: 60,  value: 25, category: "B" },
    { x: 50,  y: 40,  value: 15, category: "A" },
    { x: 15,  y: 80,  value: 5,  category: "C" },
    { x: 90,  y: 10,  value: 30, category: "B" },
    { x: 60,  y: 90,  value: 20, category: "C" },
    { x: 25,  y: 50,  value: 12, category: "D" }
];
